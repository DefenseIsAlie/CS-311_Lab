package util;

public class Border {
    public int[][] border;

    public Border(int n) {
        this.border = new int[n + 1][3];
    }
}
