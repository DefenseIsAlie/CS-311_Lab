package util;

public class Infiltrator {
    public int x; // coordinate along the infinite length (horizontal)
    public int y; // coordinate along the width (vertical)

    public Infiltrator(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
