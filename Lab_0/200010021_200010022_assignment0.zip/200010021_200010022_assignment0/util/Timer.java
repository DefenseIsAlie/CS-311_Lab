package util;

public class Timer {
    public int time;

    public Timer(int t) {
        this.time = t;
    }
}
